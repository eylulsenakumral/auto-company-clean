# LeadQualifier v4 - Analytics Feature Specification

**Version:** 4.0
**Author:** Product Team (Don Norman UX Principles)
**Date:** 2025-06-05
**Status:** Draft

---

## Executive Summary

LeadQualifier v4 transforms from a scoring tool into an **intelligence platform**. Users don't just score leads—they learn which sources produce the best prospects, how their scoring model performs over time, and how to optimize their qualification criteria.

**Core UX Philosophy:** See the signal first, explore the noise on demand.

---

## Feature 1: Scoring Analytics Dashboard

### User Stories

**As a sales manager**, I want to see my lead score distribution at a glance so I can quickly assess pipeline health without diving into individual records.

**As a sales operations specialist**, I want to identify my top 10 highest-scoring leads instantly so I can prioritize outreach efforts.

**As a VP of Sales**, I want to understand how my average scores vary by industry and tier so I can spot targeting gaps.

**As a sales analyst**, I want to see score trends over time so I can detect seasonal patterns or the impact of scoring model changes.

### Wireframe Description

```
┌─────────────────────────────────────────────────────────────────┐
│  LEADQUALIFIER v4                    [Score] [Analytics] [Settings]│
├─────────────────────────────────────────────────────────────────┤
│                                                                   │
│  ┌─ SCORING OVERVIEW ──────────────────────────────────────┐    │
│  │                                                           │    │
│  │  Total Leads: 1,247     Avg Score: 58.3     Hot Leads: 342  │    │
│  │  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │    │
│  │  │ This Week  │  This Month  │  All Time               │    │
│  │  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │    │
│  └───────────────────────────────────────────────────────────┘    │
│                                                                   │
│  ┌─ SCORE DISTRIBUTION ─────────────────────────────────────┐    │
│  │                                                           │    │
│  │  Histogram:                                              │    │
│  │                                                           │    │
│  │     Hot (75+) ▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆ 342 (27%)         │    │
│  │     Warm (50-74) ▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆ 512 (41%)    │    │
│  │     Cool (25-49) ▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆ 289 (23%)     │    │
│  │     Cold (0-24) ▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆▆ 104 (8%)       │    │
│  │                                                           │    │
│  └───────────────────────────────────────────────────────────┘    │
│                                                                   │
│  ┌─ TOP 10 LEADS ───────────────────────┐  ┌─ BY INDUSTRY ────────┐│
│  │  Rank  Domain              Score      │  │  SaaS        █████ 62 ││
│  │  ────────────────────────────────────  │  │  FinTech     █████ 58 ││
│  │  1     stripe.com         94/100 🔥  │  │  E-commerce  ████ 54  ││
│  │  2     notion.so          91/100 🔥  │  │  Agency      ███ 48   ││
│  │  3     airtable.com       89/100 🔥  │  │  Other       ██ 41    ││
│  │  4     linear.app         87/100 🔥  │  │                        ││
│  │  5     claude.ai          85/100 🔥  │  └────────────────────────┘│
│  │  ...                                       ┌─ BY TIER ───────────┐│
│  │  10    figma.com          78/100 🔥  │  │  Hot    ████████ 342  ││
│  └───────────────────────────────────────────  │  Warm   █████████ 512  ││
│                                                  │  Cool   █████ 289    ││
│                                                  │  Cold   ██ 104      ││
│                                                  └────────────────────┘│
│                                                                   │
│  ┌─ SCORE TRENDS (Last 30 Days) ─────────────────────────────┐    │
│  │                                                           │    │
│  │  100 │                                            •••     │    │
│  │   75 │                                  ••••••••••••••••••••    │    │
│  │   50 │                    ••••••••••••••                   │    │
│  │   25 │          •••••••••                                   │    │
│  │    0 └───────────────────────────────────────────────    │    │
│  │        Jun 1    Jun 8    Jun 15    Jun 22    Jun 29       │    │
│  │                                                           │    │
│  │  Legend: • Avg Score │ ─ Hot Leads Count                │    │
│  └───────────────────────────────────────────────────────────┘    │
│                                                                   │
└───────────────────────────────────────────────────────────────────┘
```

### Data Structure

```javascript
// localStorage: 'leadQualifierAnalytics'

{
  // Summary statistics (computed on-demand)
  summary: {
    totalLeads: 1247,
    avgScore: 58.3,
    hotLeads: 342,
    warmLeads: 512,
    coolLeads: 289,
    coldLeads: 104,
    lastUpdated: '2025-06-05T10:30:00Z'
  },

  // Score distribution buckets
  distribution: {
    hot: { count: 342, percentage: 27.4 },
    warm: { count: 512, percentage: 41.1 },
    cool: { count: 289, percentage: 23.2 },
    cold: { count: 104, percentage: 8.3 }
  },

  // Top leads (cached, recomputed on score changes)
  topLeads: [
    { domain: 'stripe.com', score: 94, tier: 'hot', timestamp: '...' },
    { domain: 'notion.so', score: 91, tier: 'hot', timestamp: '...' },
    // ... up to 10
  ],

  // Average scores by dimension
  byIndustry: {
    saas: { avg: 62, count: 342 },
    fintech: { avg: 58, count: 187 },
    ecommerce: { avg: 54, count: 234 },
    agency: { avg: 48, count: 156 },
    other: { avg: 41, count: 328 }
  },

  byTier: {
    hot: { count: 342, avgScore: 82.3 },
    warm: { count: 512, avgScore: 61.7 },
    cool: { count: 289, avgScore: 37.2 },
    cold: { count: 104, avgScore: 15.8 }
  },

  // Time series data (daily buckets)
  trends: [
    { date: '2025-06-01', avgScore: 56.2, hotCount: 28, totalScored: 12 },
    { date: '2025-06-02', avgScore: 58.1, hotCount: 35, totalScored: 18 },
    // ... last 30 days
  ]
}
```

### UX Principles Applied

1. **Progressive Disclosure**
   - First glance: Summary metrics (3 key numbers)
   - Second glance: Distribution histogram (visual pattern)
   - Deep dive: Top lists, trends, breakdowns

2. **Visual Affordance**
   - Hot/Warm/Cool/Cold bars use existing tier colors (instant recognition)
   - Length of bars maps directly to quantity (no labels needed initially)
   - Trend line shows direction without needing values

3. **Natural Mapping**
   - Higher bars = more leads (universal metaphor)
   - Higher on graph = higher scores (spatial metaphor)
   - Color mapping matches tier system (consistency)

### Success Criteria

- [ ] Dashboard renders in < 100ms with 1,000 leads
- [ ] All metrics update immediately after scoring a lead
- [ ] Top 10 reflects current sorting (new high scores appear instantly)
- [ ] Trends show accurate daily averages (recomputed on load)
- [ ] Distribution percentages sum to 100%
- [ ] Clicking a lead in Top 10 opens that lead in main view

---

## Feature 2: Lead Source Tracking

### User Stories

**As a marketing manager**, I want to tag each lead with its source (e.g., "LinkedIn Ads", "Cold Email", "Referral") so I can measure campaign effectiveness.

**As a growth specialist**, I want to see which sources produce the highest average scores so I can double down on high-quality channels.

**As a sales lead**, I want to compare lead volume and quality across sources so I can justify marketing budget allocation.

### Wireframe Description

```
┌─────────────────────────────────────────────────────────────────┐
│  SCORING FORM                                    [Analytics]      │
├─────────────────────────────────────────────────────────────────┤
│                                                                   │
│  Domain:               [__________________________________]       │
│  Company Size:         [5000+            ▼]                     │
│  Industry:             [SaaS             ▼]                     │
│  Funding Stage:        [Series C         ▼]                     │
│  Growth Rate:          [Rapid            ▼]                     │
│  Tech Score:           [████━━━━━━━━━━] 85                        │
│                                                                   │
│  ┌─ SOURCE (NEW) ──────────────────────────────────────────┐    │
│  │  Where did this lead come from?                         │    │
│  │                                                         │    │
│  │  [🔍 Search sources...] or select below:               │    │
│  │                                                         │    │
│  │  [✓ LinkedIn Ads]   [Cold Email]   [Referral]          │    │
│  │  [Website]         [Partner]      [Other]              │    │
│  │                                                         │    │
│  │  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │    │
│  │  💡 Tip: Sources appear in analytics. Track where your  │    │
│  │     best leads come from!                              │    │
│  └─────────────────────────────────────────────────────────┘    │
│                                                                   │
│  [Score This Lead]                                               │
│                                                                   │
└───────────────────────────────────────────────────────────────────┘
```

**Analytics - Source Performance View:**

```
┌─────────────────────────────────────────────────────────────────┐
│  SOURCE PERFORMANCE                                              │
├─────────────────────────────────────────────────────────────────┤
│                                                                   │
│  ┌─ SOURCE COMPARISON ────────────────────────────────────┐    │
│  │                                                           │    │
│  │  Source          Leads    Avg Score    Hot Rate          │    │
│  │  ─────────────────────────────────────────────────────  │    │
│  │  LinkedIn Ads    234      █████ 72    ████████ 34%       │    │
│  │  Referral        89      ██████ 68    ███████ 42%       │    │
│  │  Website         312      ████ 54     ████ 18%          │    │
│  │  Cold Email      456      ███ 48      ██ 12%            │    │
│  │  Partner         67       █████ 61    ███████ 28%       │    │
│  │  Other           89       ██ 42       █ 8%              │    │
│  │                                                           │    │
│  └───────────────────────────────────────────────────────────┘    │
│                                                                   │
│  ┌─ QUALITY vs QUANTITY MATRIX ─────────────────────────────┐    │
│  │                                                           │    │
│  │  High Quality                                            │    │
│  │      │                    • Referral                     │    │
│  │      │           • LinkedIn Ads                         │    │
│  │      │     • Partner                                     │    │
│  │  ────┼───────────────────────────────────               │    │
│  │      │                                  • Website         │    │
│  │      │              • Cold Email                        │    │
│  │ Low Quality     • Other                                 │    │
│  │                                                           │    │
│  │         Low Volume                      High Volume      │    │
│  │                                                           │    │
│  └───────────────────────────────────────────────────────────┘    │
│                                                                   │
│  ┌─ RECOMMENDATION ─────────────────────────────────────────┐    │
│  │  💡 Your best leads come from Referrals (avg: 68).         │    │
│  │     Consider increasing referral incentives.               │    │
│  └───────────────────────────────────────────────────────────┘    │
│                                                                   │
└───────────────────────────────────────────────────────────────────┘
```

### Data Structure

```javascript
// Lead record with source
{
  domain: 'stripe.com',
  companySize: '5000+',
  industry: 'fintech',
  fundingStage: 'series_c',
  growthRate: 'rapid',
  techScore: 95,
  source: 'LinkedIn Ads',  // NEW FIELD
  score: 94,
  tier: 'hot',
  timestamp: '2025-06-05T10:30:00Z'
}

// Analytics: source performance
{
  sourcePerformance: {
    'LinkedIn Ads': {
      leads: 234,
      avgScore: 72,
      hotCount: 79,
      hotRate: 0.34,
      totalScore: 16848
    },
    'Referral': {
      leads: 89,
      avgScore: 68,
      hotCount: 37,
      hotRate: 0.42,
      totalScore: 6052
    },
    // ... other sources
  }
}
```

### Source Management

```javascript
// localStorage: 'leadQualifierSources'

{
  // User-defined sources with usage stats
  sources: [
    { name: 'LinkedIn Ads', uses: 234, createdAt: '2025-05-01' },
    { name: 'Referral', uses: 89, createdAt: '2025-05-01' },
    { name: 'Website', uses: 312, createdAt: '2025-05-01' },
    { name: 'Cold Email', uses: 456, createdAt: '2025-05-01' },
    { name: 'Partner', uses: 67, createdAt: '2025-05-01' },
    { name: 'Other', uses: 89, createdAt: '2025-05-01' }
  ],

  // Auto-suggested sources (from past leads)
  suggestions: ['Trade Show', 'Webinar', 'Content Marketing']
}
```

### UX Principles Applied

1. **Smart Defaults**
   - 6 common sources pre-loaded (covers 80% of cases)
   - Source selection persists from previous lead
   - "Other" option captures edge cases

2. **Error Prevention**
   - Source field is optional (doesn't block scoring)
   - Free-form input normalizes to existing sources
   - No validation errors—just auto-suggest matches

3. **Instant Feedback**
   - Source analytics update immediately after scoring
   - Visual matrix shows quadrant positioning instantly
   - Recommendations auto-generate from data

### Success Criteria

- [ ] Source field added to scoring form without breaking existing flow
- [ ] Source selection persists between leads (last used = default)
- [ ] Source performance metrics update in real-time
- [ ] Quality vs Quantity matrix renders correctly
- [ ] Recommendation algorithm identifies best/worst sources accurately
- [ ] Source list can be edited in Settings (add, remove, rename)

---

## Feature 3: A/B Testing Framework

### User Stories

**As a sales ops lead**, I want to save multiple scoring weight configurations so I can test different scoring models without losing my working setup.

**As a data-driven seller**, I want to name and describe each model (e.g., "Aggressive Growth Model") so I can remember the rationale behind different configurations.

**As a sales analyst**, I want to compare how the same leads score under different models so I can understand the impact of weight changes.

### Wireframe Description

```
┌─────────────────────────────────────────────────────────────────┐
│  SETTINGS                                                        │
├─────────────────────────────────────────────────────────────────┤
│                                                                   │
│  ┌─ SCORING MODELS ──────────────────────────────────────────┐    │
│  │                                                           │    │
│  │  Active Model:  [Growth-Focused v2 ▼]                    │    │
│  │                                                           │    │
│  │  ┌─ GROWTH-FOCUSED v2 (Active) ─────────────────────────┐ │    │
│  │  │ Size:     20%  [████████░░░░░░░]                      │ │    │
│  │  │ Funding:  15%  [██████░░░░░░░░░]                      │ │    │
│  │  │ Growth:   35%  [██████████████░░]  (Boosted!)         │ │    │
│  │  │ Industry: 15%  [██████░░░░░░░░]                      │ │    │
│  │  │ Tech:     15%  [██████░░░░░░░░]                      │ │    │
│  │  │                                            [✓ Active]  │ │    │
│  │  │ "Prioritizes fast-growing companies over           │ │    │
│  │  │  established players. Best for outbound to high-   │ │    │
│  │  │  growth startups."                                 │ │    │
│  │  └─────────────────────────────────────────────────────┘ │    │
│  │                                                           │    │
│  │  ┌─ BALANCED DEFAULT ───────────────────────────────────┐ │    │
│  │  │ Size: 25%  Funding: 25%  Growth: 20%                  │ │    │
│  │  │ Industry: 15%  Tech: 15%                             │ │    │
│  │  │                                        [Activate ▼]  │ │    │
│  │  │ "Balanced approach for general B2B prospecting"    │ │    │
│  │  └─────────────────────────────────────────────────────┘ │    │
│  │                                                           │    │
│  │  ┌─ ENTERPRISE-FOCUSED ─────────────────────────────────┐ │    │
│  │  │ Size: 40%  Funding: 30%  Growth: 10%                  │ │    │
│  │  │ Industry: 10%  Tech: 10%                             │ │    │
│  │  │                                        [Activate ▼]  │ │    │
│  │  │ "Targets large, funded companies for     │ │    │
│  │  │  enterprise sales motions"                │ │    │
│  │  └─────────────────────────────────────────────────────┘ │    │
│  │                                                           │    │
│  │  [➕ Create New Model]                                    │    │
│  └───────────────────────────────────────────────────────────┘    │
│                                                                   │
│  ┌─ MODEL COMPARISON ─────────────────────────────────────────┐    │
│  │                                                           │    │
│  │  Compare how leads score under different models:         │    │
│  │                                                           │    │
│  │  Model A: [Growth-Focused v2 ▼]  Model B: [Balanced ▼]   │    │
│  │                                                           │    │
│  │  Domain              Model A    Model B    Delta         │    │
│  │  ─────────────────────────────────────────────────────  │    │
│  │  stripe.com          94/100     89/100     +5 🔼         │    │
│  │  notion.so            91/100     88/100     +3 🔼         │    │
│  │  acme-agency.com      45/100     58/100     -13 🔽        │    │
│  │  startup.io           72/100     61/100     +11 🔼        │    │
│  │  megacorp.com         52/100     79/100     -27 🔽        │    │
│  │                                                           │    │
│  │  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │    │
│  │  Impact: Model A boosts high-growth leads by +8 avg.     │    │
│  │          Model A reduces enterprise scores by -15 avg.    │    │
│  └───────────────────────────────────────────────────────────┘    │
│                                                                   │
└───────────────────────────────────────────────────────────────────┘
```

**Create/Edit Model Modal:**

```
┌─────────────────────────────────────────────────────────────────┐
│  CREATE SCORING MODEL                                             │
├─────────────────────────────────────────────────────────────────┤
│                                                                   │
│  Model Name:        [__________________________________]         │
│  Description:       [Describe when to use this model...]         │
│                     [__________________________________]         │
│                     [__________________________________]         │
│                                                                   │
│  ┌─ WEIGHT CONFIGURATION ───────────────────────────────────┐    │
│  │                                                           │    │
│  │  Company Size    [██████████░░░░] 50%  [+][-]             │    │
│  │  Funding Stage   [██████░░░░░░░░] 25%  [+][-]             │    │
│  │  Growth Rate     [████░░░░░░░░░░] 15%  [+][-]             │    │
│  │  Industry        [███░░░░░░░░░░░] 10%  [+][-]             │    │
│  │  Tech Score      [███░░░░░░░░░░░] 10%  [+][-]             │    │
│  │                                                           │    │
│  │  Total: 110% ⚠️ Must equal 100%                           │    │
│  └───────────────────────────────────────────────────────────┘    │
│                                                                   │
│  [Save Model]  [Cancel]                                           │
│                                                                   │
└───────────────────────────────────────────────────────────────────┘
```

### Data Structure

```javascript
// localStorage: 'leadQualifierModels'

{
  // List of scoring models
  models: [
    {
      id: 'growth-v2',
      name: 'Growth-Focused v2',
      description: 'Prioritizes fast-growing companies over ' +
                    'established players. Best for outbound to ' +
                    'high-growth startups.',
      weights: {
        size: 20,
        funding: 15,
        growth: 35,
        industry: 15,
        tech: 15
      },
      isActive: true,
      createdAt: '2025-05-15T10:00:00Z',
      lastUsed: '2025-06-05T09:30:00Z'
    },
    {
      id: 'balanced-default',
      name: 'Balanced Default',
      description: 'Balanced approach for general B2B prospecting',
      weights: {
        size: 25,
        funding: 25,
        growth: 20,
        industry: 15,
        tech: 15
      },
      isActive: false,
      createdAt: '2025-05-01T10:00:00Z',
      lastUsed: '2025-06-04T16:45:00Z'
    }
  ],

  // Model comparison cache
  comparisons: {
    'growth-v2_vs_balanced-default': {
      modelAId: 'growth-v2',
      modelBId: 'balanced-default',
      computedAt: '2025-06-05T10:00:00Z',
      sampleSize: 50,
      avgDelta: 8.3,
      impacts: {
        growthCompanies: +11.2,
        enterpriseCompanies: -15.4,
        earlyStage: +3.8
      }
    }
  }
}
```

### UX Principles Applied

1. **Progressive Disclosure**
   - First view: Active model + quick activation
   - Second view: All models with descriptions
   - Third view: Model creation/comparison

2. **Conceptual Model Clarity**
   - Models have names AND descriptions (rationale)
   - Weight sliders show percentage + visual bar
   - Comparison shows concrete delta (not abstract)

3. **Error Prevention**
   - Weight totals validated before save
   - Can't activate invalid model (soft block)
   - Comparison auto-selects most recently used models

4. **Natural Mapping**
   - Higher weight = longer bar (instant comprehension)
   - Delta shows +/- with emoji direction (universal)
   - Active model has clear checkmark indicator

### Success Criteria

- [ ] At least 3 default models ship with v4
- [ ] Models can be created, edited, and deleted
- [ ] Weight validation prevents totals != 100%
- [ ] Activating a model immediately applies to new scores
- [ ] Historical scores can be re-computed under different models
- [ ] Model comparison shows accurate deltas
- [ ] Model descriptions explain WHEN to use (not just WHAT)

---

## Technical Implementation Notes

### File Structure

- Single HTML file (v4.html)
- All data in localStorage
- No external dependencies (except fonts + PapaParse for CSV)
- All rendering client-side

### localStorage Keys

| Key | Purpose | Schema |
|-----|---------|--------|
| `leadQualifierScores` | Lead history | Array of scored leads |
| `leadQualifierModels` | Scoring models | Array of model configs |
| `leadQualifierSources` | Source definitions | Array of source strings |
| `leadQualifierThresholds` | Tier cutoffs | { hot, warm, cool } |
| `leadQualifierWeights` | Active weights | { size, funding, growth, industry, tech } |
| `leadQualifierAnalytics` | Computed metrics | Summary, distribution, trends |
| `leadQualifierWebhooks` | CRM endpoints | { hubSpot, salesforce } |

### Performance Considerations

1. **Lazy Computation**
   - Analytics summary computed on-demand, cached for 5 min
   - Top 10 recomputed only when scores change
   - Trends bucketized by day (not raw timestamps)

2. **Pagination**
   - If leads > 1000, analytics uses sampled subset
   - Model comparison limited to 50 leads (most recent)

3. **Storage Limits**
   - localStorage has ~5MB limit
   - At 500 bytes per lead = ~10,000 leads max
   - Consider pruning old leads beyond limit

### Migration Path (v3 → v4)

```javascript
// On first v4 load, run migration:
function migrateToV4() {
  // 1. Initialize default models
  if (!localStorage.getItem('leadQualifierModels')) {
    localStorage.setItem('leadQualifierModels', JSON.stringify(defaultModels));
  }

  // 2. Initialize default sources
  if (!localStorage.getItem('leadQualifierSources')) {
    localStorage.setItem('leadQualifierSources', JSON.stringify(defaultSources));
  }

  // 3. Backfill source field for existing leads
  const scores = JSON.parse(localStorage.getItem('leadQualifierScores') || '[]');
  const migratedScores = scores.map(lead => ({
    ...lead,
    source: lead.source || 'Unknown'  // Default for v3 leads
  }));
  localStorage.setItem('leadQualifierScores', JSON.stringify(migratedScores));

  // 4. Migrate weights to model format
  const oldWeights = JSON.parse(localStorage.getItem('leadQualifierWeights'));
  const balancedModel = {
    id: 'migrated-balanced',
    name: 'Balanced (Migrated)',
    description: 'Your v3 scoring configuration',
    weights: oldWeights,
    isActive: true,
    createdAt: new Date().toISOString(),
    lastUsed: new Date().toISOString()
  };
  // Add to models array...
}
```

---

## Design System Extensions

### New Components

1. **Analytics Card**
   - Same base as v3 cards
   - Added: Compact metric display, trend sparklines

2. **Histogram Bar**
   - Reusable tier-colored bar component
   - Labels shown on hover

3. **Model Selector**
   - Dropdown with model preview
   - Description text inline

4. **Comparison Table**
   - Delta column with color-coded arrows
   - Sortable by any column

### Color Extensions

```css
/* New colors for source/analytics */
:root {
  --source-linkedin: #0077b5;
  --source-referral: #00d4aa;
  --source-website: #3b82f6;
  --source-cold-email: #8b5cf6;
  --source-partner: #f59e0b;
  --source-other: #64748b;

  --delta-positive: #10b981;
  --delta-negative: #ef4444;
  --delta-neutral: #64748b;
}
```

---

## User Flow Examples

### Flow 1: Quick Lead Score with Source

```
1. User opens app
2. Enters domain (auto-fills from clipboard if URL)
3. Selects industry template
4. Sees pre-filled source (last used: "LinkedIn Ads")
5. Adjusts tech score slider
6. Clicks "Score This Lead"
7. Result shows with tier badge
8. Toast: "Score saved! 234th lead from LinkedIn Ads"
9. User clicks Analytics tab
10. Sees updated source distribution (LinkedIn Ads now 235)
```

### Flow 2: Model Comparison Experiment

```
1. User opens Settings → Scoring Models
2. Clicks "Create New Model"
3. Enters name: "Aggressive Growth"
4. Adjusts weights: Boosts Growth to 40%, reduces Size
5. Clicks "Save Model"
6. Switches to Analytics → Model Comparison
7. Selects: "Aggressive Growth" vs "Balanced Default"
8. Sees comparison table: 3 leads gained +10, 5 leads lost -15
9. Returns to main view
10. Activates "Aggressive Growth" model
11. Re-scores existing lead: Score goes from 72 → 81
12. Toast: "Score increased by 9 points under new model"
```

### Flow 3: Source-Based Decision

```
1. User opens Analytics
2. Views Source Performance table
3. Notices: Referrals have 42% hot rate (highest)
4. Notices: Cold Email has only 12% hot rate
5. Clicks "View Details" on Referrals
6. Sees: 89 leads, avg score 68
7. Decision: "Let's double down on referral program"
8. Returns to scoring form
9. Tags next lead with source: "Referral"
10. Lead scores 78/100 (Hot tier)
11. User feels validated: "Another high-quality referral"
```

---

## Accessibility Considerations

### Keyboard Navigation
- All analytics controls accessible via Tab
- Arrow keys for sliders
- Escape closes modals

### Screen Reader Support
- ARIA labels on all charts
- Data tables with proper headers
- Color not sole indicator (icons + text)

### Visual Clarity
- Minimum contrast ratio 4.5:1
- Font sizes ≥ 14px
- Tap targets ≥ 44x44px

---

## Testing Plan

### Unit Tests (Manual)

1. **Dashboard Metrics**
   - Verify counts match actual lead totals
   - Verify avg score calculation (2 decimals)
   - Verify distribution sums to 100%

2. **Source Tracking**
   - Tag lead with source → verify analytics update
   - Create new source → verify appears in dropdown
   - Edit source name → verify retroactive update

3. **Model Management**
   - Create model with invalid weights → verify error
   - Activate model → verify new scores use it
   - Compare models → verify delta accuracy

### Integration Tests

1. **End-to-End**
   - Score 5 leads with different sources
   - Verify dashboard shows correct distribution
   - Create new model
   - Re-score 1 lead
   - Verify comparison shows correct delta

2. **Edge Cases**
   - 0 leads → dashboard shows "No data yet"
   - 1 lead → dashboard shows single lead
   - 10,000 leads → verify performance < 2s load

---

## Success Metrics (Post-Launch)

### Adoption
- % of users who view Analytics dashboard (target: 60%)
- % of leads tagged with source (target: 80%)
- Avg number of models created per user (target: 2.3)

### Engagement
- Avg time spent in Analytics per session (target: 45s)
- % of users who compare models (target: 25%)
- % of users who create custom models (target: 15%)

### Quality Signals
- % of users who activate non-default model (target: 30%)
- % of leads re-scored under new model (target: 10%)
- Reduction in "unknown" source over time (target: < 5%)

---

## Open Questions

1. **Data Retention**
   - Should we auto-delete leads older than 1 year?
   - Should we export to CSV before deletion?

2. **Model Sharing**
   - Should users be able to export/import model configs?
   - Should we provide model templates by industry?

3. **Source Attribution**
   - How should we handle leads from multiple touchpoints?
   - First touch vs. last touch attribution?

4. **Privacy**
   - Should analytics be opt-in for enterprise customers?
   - Any GDPR considerations for lead history?

---

## Next Steps

1. **Design Validation**
   - Create interactive Figma prototype
   - User test with 5 sales professionals
   - Iterate based on feedback

2. **Technical Spike**
   - Build histogram rendering (vanilla JS)
   - Implement model comparison algorithm
   - Validate localStorage performance with 10K leads

3. **Implementation Phasing**
   - Phase 1: Dashboard + Source Tracking
   - Phase 2: Model Management + Comparison
   - Phase 3: Advanced analytics ( cohorts, funnels)

4. **Documentation**
   - User guide for analytics features
   - Video walkthrough (3 min)
   - Model configuration best practices

---

**Document Version:** 1.0
**Last Updated:** 2025-06-05
**Next Review:** After design validation
