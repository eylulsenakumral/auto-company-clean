# LeadQualifier v4

Interactive lead scoring tool with analytics dashboard.

## Quick Start

1. Extract this package
2. Open `leadqualifier.html` in any modern browser
3. Start scoring leads!

## Features

### v4 New Features
- **Analytics Dashboard** (4 tabs): Overview, Sources, Models, History
- **Lead Source Tracking**: 9 source options with performance analytics
- **A/B Testing**: Save, compare, and switch between scoring models
- **Complete History**: Filterable, exportable scoring history

### Existing Features (v1-v3)
- Interactive scoring with 8 signals
- Industry templates (SaaS, E-commerce, Agency)
- Demo mode for testing
- Comparison table
- CRM webhooks (HubSpot, Salesforce)
- CSV import/export
- Custom weights and thresholds

## Migration from v3

v4 automatically migrates your v3 data on first open.
All scores, settings, and webhooks are preserved.

## Data Storage

All data stored in your browser's localStorage.
Nothing is sent to external servers.

## System Requirements

- Modern browser (Chrome, Firefox, Safari, Edge)
- JavaScript enabled
- ~5MB localStorage available

## Support

Report issues: https://github.com/eylulsenakumral/auto-company/issues

## Version History

- v4: Analytics dashboard, A/B testing, source tracking
- v3: Industry templates, demo mode, comparison
- v2: CSV export, CRM webhooks, custom weights
- v1: Initial release
