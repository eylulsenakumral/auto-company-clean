# env-diff

CLI tool comparing local `.env` vs production environment to solve "works on my machine" debugging.

## Installation

```bash
npm install -g env-diff
```

## Usage

Compare your local environment with production:

```bash
# Compare with production .env file
env-diff compare --prod .env.production

# Specify custom local file
env-diff compare -l .env.local -p .env.production

# Short form
env-diff compare -p .env.prod
```

## What it shows

- **Missing vars**: Environment variables present in production but missing locally
- **Extra vars**: Environment variables present locally but not in production (potential secrets risk!)
- **Different values**: Variables with different values between environments
- **Secret masking**: Values containing SECRET, KEY, TOKEN, PASSWORD, API, or PRIVATE are automatically masked
- **Runtime version**: Node.js version info

## Example Output

```
⚠️  Missing in local (present in production):
┌──────────────────────┬──────────────────────────────┐
│ Variable             │ Production Value              │
├──────────────────────┼──────────────────────────────┤
│ DATABASE_URL         │ postgres://...               │
│ STRIPE_SECRET_KEY    ****rk2j4****                  │
└──────────────────────┴──────────────────────────────┘

➕ Extra in local (not in production):
┌──────────────────────┬──────────────────────────────┐
│ Variable             │ Local Value                   │
├──────────────────────┼──────────────────────────────┤
│ TEST_MODE            │ true                          │
│ DEV_API_KEY          ****1234****                    │
└──────────────────────┴──────────────────────────────┘

🔄 Different values:
┌──────────────────────┬─────────────────┬─────────────────┐
│ Variable             │ Local            │ Production      │
├──────────────────────┼─────────────────┼─────────────────┤
│ NODE_ENV             │ development      │ production      │
│ API_RATE_LIMIT       │ 100              │ 1000            │
└──────────────────────┴─────────────────┴─────────────────┘

📌 Runtime Version:
   Node.js: v20.14.0
```

## Features

- **Zero config**: Works out of the box with standard `.env` files
- **Secret detection**: Automatically masks sensitive values
- **Clear output**: Formatted tables showing differences at a glance
- **No auth required**: Works with local files only (no API keys needed)

## Requirements

- Node.js >= 18.0.0

## License

MIT
