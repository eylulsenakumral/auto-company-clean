import { Octokit } from 'octokit';
/**
 * Get authenticated Octokit instance using gh CLI token
 * Uses the same authentication as GitHub CLI
 */
export declare function getAuthenticatedOctokit(): Promise<Octokit>;
