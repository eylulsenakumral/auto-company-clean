import { Octokit } from 'octokit';
import { CycleTimeResult } from '../commands/pr-cycle-time.js';
interface AnalysisOptions {
    octokit: Octokit;
    org: string;
    repo?: string;
    since: Date;
    limit: number;
}
/**
 * Analyze PR cycle time for an organization or repo
 * Returns breakdown of time spent in each stage
 */
export declare function analyzePRCycleTime(options: AnalysisOptions): Promise<CycleTimeResult>;
export {};
