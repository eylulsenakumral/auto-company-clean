import { Command } from '@oclif/core';
export default class PRCycleTime extends Command {
    static description: string;
    static examples: string[];
    static flags: {
        org: import("@oclif/core/interfaces").OptionFlag<string, import("@oclif/core/interfaces").CustomOptions>;
        days: import("@oclif/core/interfaces").OptionFlag<number, import("@oclif/core/interfaces").CustomOptions>;
        repo: import("@oclif/core/interfaces").OptionFlag<string | undefined, import("@oclif/core/interfaces").CustomOptions>;
        limit: import("@oclif/core/interfaces").OptionFlag<number, import("@oclif/core/interfaces").CustomOptions>;
    };
    run(): Promise<void>;
    private displayResults;
}
export interface CycleTimeResult {
    totalCount: number;
    avgCycleTime: number;
    breakdown: Record<string, number>;
    bottleneck: {
        stage: string;
        avgDays: number;
    };
    stuckPRs: Array<{
        title: string;
        cycleTime: number;
        url: string;
    }>;
}
