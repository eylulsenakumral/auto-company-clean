# gh-analytics

GitHub organization analytics CLI - Analyze PR cycle times and identify bottlenecks.

## Installation

### Option 1: Via npm (recommended)
```bash
npm install -g gh-analytics
```

### Option 2: Via GitHub Releases
```bash
# Download from https://github.com/eylulsenakumral/github-org-analyzer-cli/releases
# Then install locally
npm install -g ./gh-analytics-*.tgz
```

## Prerequisites

- GitHub CLI installed and authenticated (`gh auth login`)
- Node.js 18+

## Usage

### Analyze organization PRs

```bash
gh-analytics pr-cycle-time --org=vercel --days=30
```

### Analyze specific repo

```bash
gh-analytics pr-cycle-time --org=vercel --repo=vercel/next.js --days=30
```

### Limit analysis

```bash
gh-analytics pr-cycle-time --org=facebook --days=7 --limit=50
```

## Output

The command displays:

1. **Total PRs analyzed** - Number of PRs in the time period
2. **Average cycle time** - Mean time from PR creation to merge
3. **Breakdown by stage** - Time spent in each stage:
   - First response - Time to first reviewer comment
   - Review time - Time from first response to merge
   - Merge time - Time from approval to merge
4. **Bottleneck** - Stage with the longest average time
5. **Top 5 stuck PRs** - PRs with longest cycle times

## Development

```bash
# Install dependencies
npm install

# Build
npm run build

# Run locally (dev mode - uses TypeScript source)
npm run dev pr-cycle-time --org=vercel --days=30

# Or run after build (uses compiled JS)
npm run build && node ./bin/run pr-cycle-time --org=vercel --days=30

# Publish
npm publish
```

## License

MIT
