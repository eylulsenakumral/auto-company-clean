module.exports=[81721,(e,o,d)=>{}];

//# sourceMappingURL=0jn3_landing__next-internal_server_app_favicon_ico_route_actions_0ypctrb.js.map