module.exports=[9428,(a,b,c)=>{}];

//# sourceMappingURL=0jn3_landing__next-internal_server_app__global-error_page_actions_0vzhamx.js.map