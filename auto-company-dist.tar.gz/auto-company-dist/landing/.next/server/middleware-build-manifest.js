globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/vFdU2bE5RvaR7Gb5xja6Z/_buildManifest.js",
    "static/vFdU2bE5RvaR7Gb5xja6Z/_ssgManifest.js",
    "static/vFdU2bE5RvaR7Gb5xja6Z/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/407o4a9cevhb7.js",
    "static/chunks/0zygw72f_vf-j.js",
    "static/chunks/40p_qf5fk50cu.js",
    "static/chunks/turbopack-2i311lvii_xzy.js"
  ]
};
