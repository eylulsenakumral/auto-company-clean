1:"$Sreact.fragment"
2:I[63589,["/_next/static/chunks/3l8n6rcoeb-xf.js"],"default"]
3:I[90840,["/_next/static/chunks/3l8n6rcoeb-xf.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"vFdU2bE5RvaR7Gb5xja6Z"}
