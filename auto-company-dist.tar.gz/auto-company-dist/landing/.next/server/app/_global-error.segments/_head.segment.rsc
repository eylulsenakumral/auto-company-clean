1:"$Sreact.fragment"
2:I[67949,["/_next/static/chunks/3l8n6rcoeb-xf.js"],"ViewportBoundary"]
3:I[67949,["/_next/static/chunks/3l8n6rcoeb-xf.js"],"MetadataBoundary"]
4:"$Sreact.suspense"
5:I[9212,["/_next/static/chunks/3l8n6rcoeb-xf.js"],"IconMark"]
0:{"rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","link","0",{"rel":"icon","href":"/favicon.ico?favicon.2vob68tjqpejf.ico","sizes":"256x256","type":"image/x-icon"}],["$","$L5","1",{}]]}]}]}],null]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"vFdU2bE5RvaR7Gb5xja6Z"}
