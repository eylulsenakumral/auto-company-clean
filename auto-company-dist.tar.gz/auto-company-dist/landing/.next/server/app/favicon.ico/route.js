var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[externals]_next_dist_1hsuqpg._.js")
R.c("server/chunks/[root-of-the-server]__1512apk._.js")
R.c("server/chunks/0jn3_landing__next-internal_server_app_favicon_ico_route_actions_0ypctrb.js")
R.m(2675)
module.exports=R.m(2675).exports
